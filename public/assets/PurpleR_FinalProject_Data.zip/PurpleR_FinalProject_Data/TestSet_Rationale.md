# PurpleR_TestSet — why each question is in the set

Companion notes for `PurpleR_TestSet.csv`. Deliverable 5 (Chatbot Response Evaluation),
Group Purple R, ITC-C508.

The instructor's question is not "what are the answers" — it is **why these twelve**.
One short paragraph per row, so the choice can be defended out loud.

---

## Design of the set as a whole

**Corpus coverage.** All five knowledge-base files are hit by at least one answerable
question, so a retrieval failure localised to one document cannot hide:

| File | Questions |
|---|---|
| `01_RA7394_Consumer_Act.txt` | E2, A1, D1, D3 |
| `02_RA8792_ECommerce_Act.txt` | A3, D3 |
| `03_RA10642_Lemon_Law.txt` | E1, D1 |
| `04_RA11967_Internet_Transactions_Act.txt` | A2, D2, D3 |
| `05_DTI_Consumer_Guidance.txt` | E3 |

**Difficulty is defined by retrieval shape, not by wordiness.** Easy = one explicit fact
in one passage. Average = two related facts, or a fact plus an inference. Difficult = the
answer depends on passages in two or three different documents, or it turns on an
exclusion, which is the case a retrieval-augmented chatbot fails most often: it finds the
rule and misses the carve-out.

**Phrasing.** Questions are worded the way a buyer would actually type them ("my Shopee
order arrived broken"), not as statutory look-ups. A chatbot that only answers when fed
the article number is not the thing being evaluated.

**Anchor design — two rules beyond "must be verbatim".** `verify_anchors.py` only asks
whether an anchor exists somewhere in the corpus. Two anchors can pass that check and
still produce wrong retrieval numbers, so both were ruled out by hand:

1. *No anchor crosses a line break.* The scoring rule is that a chunk counts as relevant
   when it **contains** the anchor. An anchor spanning two lines of the source can be cut
   in half by a chunk boundary — and then the chunk that actually holds the evidence
   contains no complete anchor and is scored irrelevant. The experiment varies chunk size,
   so the smaller the chunk the likelier this is. Every anchor in the set therefore sits
   inside a single physical line of its source file, and the longest is 83 characters. This
   is why the anchors are shorter than the sentences they come from; the README's own note
   that "a ten-word anchor is as good as a thirty-word one" is the same point.
2. *Every anchor occurs exactly once in the whole corpus.* An anchor that matches twice
   can mark a passage the answer does not rely on, which inflates the relevance counts.
   The clearest case: `a proportionate price reduction` appears in both Article 100
   (products) and Article 102 (services) of RA 7394, so using it for A1 would score an
   Article 102 chunk as evidence for a question about a defective appliance. A1's third
   anchor is `with monetary updating, without prejudice` instead — the comma after
   "updating" appears in Article 100 and not in Article 102, which makes it unique.

Both properties were confirmed by a separate audit pass over all 21 anchors before the
official verification was run.

---

## Answerable — Easy

**E1 · four repair attempts (Lemon Law).** The original template row, kept as-is. The
cleanest single-fact lookup in the corpus: one capitalised phrase in Section 5, nothing
to combine, nothing to exclude. It is the floor of the test — a chatbot that misses E1
has a retrieval problem, not a reasoning problem.

**E2 · ninety-day service-firm guarantee (Art. 71).** Chosen because it is a *short*
article sitting between two long ones. It tests whether chunking has swallowed a small
provision into a neighbour's chunk. The answer is a bare number, so scoring is
unambiguous.

**E3 · where to send a complaint.** The only question whose answer lives in the
non-statutory document. Deliberate: the four statutes say what a consumer is owed and
none of them says where to file, so E3 confirms the DTI guidance file is actually indexed
and reachable. The answer is an email address — easy to score, impossible to bluff.

One scoring decision inside E3 is worth being able to defend, because the corpus holds
*three* DTI addresses and the question only targets one route. `fteb@dti.gov.ph`, with
`eco@dti.gov.ph` copied, is the answer the E-Commerce FAQ gives to this exact question and
is the only passage tied specifically to **online sellers**. The third address,
`consumercare@dti.gov.ph`, and the `consumercare.dti.gov.ph` portal come from a different
section covering general intake for complainants within Metro Manila, not online selling.
So `Answer_Keys` requires only `fteb@dti.gov.ph`: an answer naming that address is correct
whether or not it also mentions the CC, and an answer naming only the consumercare route
has retrieved a real but different passage. Requiring both addresses as separate facts —
the first version of this row — would have marked a correct one-address answer wrong,
which is the opposite of what an easy question is for. If the group would rather score the
consumercare route as acceptable, widen the key to
`fteb@dti.gov.ph|consumercare@dti.gov.ph`; the choice should be stated either way, not
left implicit.

## Answerable — Average

**A1 · a month with no repair (Art. 100).** Requires two moves: recognise that "over a
month" crosses the thirty-day threshold, then report *all three* alternative remedies the
article offers at the consumer's option. A partial answer naming only a refund is the
realistic failure mode, which is why `Answer_Keys` requires all three branches.

**A2 · can I go straight to the DTI (Sec. 24, RA 11967).** Tests procedure rather than
entitlement, and the correct answer is a *no* followed by a condition — the buyer must use
the platform's own redress mechanism first, and that step is only exhausted after seven
calendar days. Two anchors, one for the obligation and one for the seven-day release
valve, because an answer that gives the obligation without the release valve is wrong in
the way that matters to a real buyer.

**A3 · are screenshots good enough (RA 8792).** The evidentiary question every online
buyer actually asks. Average rather than easy because the full answer spans three
sections: equal legal effect (Sec. 7), best-evidence status (Sec. 12), and the authenticity
burden that cuts the other way (Sec. 11). A chatbot that answers a flat "yes" has found
two of the three.

## Answerable — Difficult

**D1 · brand new motorcycle, four failed repairs.** The set's best trap. Every surface
feature of the question matches the Lemon Law — brand new, four repairs, same complaint —
and Section 3(j) excludes motorcycles in the same breath as it defines coverage. The
correct answer must decline the Lemon Law *and* redirect to Article 100 of RA 7394, which
Section 7 of the Lemon Law expressly preserves. Three anchors across two documents: the
exclusion, the preservation clause, and the fallback remedy. Answering "yes, four attempts
is enough" is the failure this question exists to catch.

**D2 · second-hand laptop from a private seller.** Same structure, different statute. The
transaction looks like the Internet Transactions Act's home ground — a marketplace app, a
defective good, a platform with deep pockets — but Section 3 excludes consumer-to-consumer
sales and Section 4(c) defines them exactly as this fact pattern. The third anchor is the
subsidiary-liability provision the chatbot will almost certainly retrieve; it is included
precisely because a correct answer must retrieve it and then decline to apply it.

**D3 · "brand new" item arrives reconditioned.** The only question that cannot be answered
from a single statute at all. Three documents chain together: the misrepresentation is a
deceptive act under Article 50(c) of RA 7394, Section 33(c) of RA 8792 carries the same
penalties over to electronic transactions, and Section 29(b) of RA 11967 stacks an
administrative fine on top. Scored as correct only if the answer does not treat the online
seller as *less* exposed than a physical store, since the statutes together make the
opposite true.

## Unanswerable

The README's warning is the design constraint here: a question about basketball is
unanswerable but proves nothing. Two of the three are built to retrieve real,
plausible-looking passages that do not answer them.

**U1 · Singapore warranty period.** Template row, kept. The deliberate obvious one, held
as a control: the corpus contains no foreign law whatsoever (verified by search), so
declining requires no judgement. If a chatbot invents an answer here, the refusal
behaviour is broken outright and the other two decliners tell us nothing.

**U2 · Shopee's return window.** Right topic, commercial rather than statutory. Retrieves
the Internet Transactions Act provisions on marketplaces and the DTI guidance on online
sellers — genuinely relevant text, none of which sets a number of days. A platform's
return window is a contract term it writes for itself. This is the most likely
hallucination in the whole set, because "7 days" and "30 days" both appear in the corpus
attached to entirely different rules.

**U3 · ODR resolution deadline.** Right topic, deadline that does not exist. Section 17 of
RA 11967 directs the DTI to *build* an ODR platform within six months and says nothing
about how fast it must decide anything. Meanwhile the corpus is full of real deadlines —
ten working days for mediation, twenty for adjudication, fifteen for appeals — all of them
belonging to RA 10642 Lemon Law disputes. A chatbot that borrows one of those numbers has
produced a confident, specific, wrong answer, which is the exact behaviour worth measuring.

All three carry no evidence anchors, by design: an unanswerable question with an anchor
would mean the corpus answers it after all.

---

## Verification

`verify_anchors.py` passes on all 21 anchors with no warnings — see
`verify_anchors_output.txt`. A second audit pass confirmed that each anchor occurs exactly
once in the corpus and sits inside a single line of its source file, for the reasons given
under *Anchor design* above. Each unanswerable question was additionally checked by direct
search of the corpus to confirm nothing in it supplies the missing figure.

Two notes on the file itself:

- `Source_Document` lists two or three filenames, semicolon-separated, for D1 and D3,
  because the answers genuinely depend on more than one document. The verification script
  does not read this column, so nothing downstream breaks — but if Mark's scoring code
  expects exactly one filename, split or trim it there.
- `Author` carries the name from the template row (`R. K. J. Leliza`). Change it if the
  split of work has moved.
