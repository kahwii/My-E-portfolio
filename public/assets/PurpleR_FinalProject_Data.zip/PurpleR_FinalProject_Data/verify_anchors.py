# -*- coding: utf-8 -*-
"""
Checks PurpleR_TestSet.csv against the corpus in knowledge_base/.

Run it in the folder that holds both:

    python verify_anchors.py

Every evidence anchor must be found verbatim in at least one corpus file. An anchor that
is not found would silently break the retrieval metrics, so this script exits with an
error until all of them pass.
"""
import csv
import glob
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
CSV = os.path.join(HERE, "PurpleR_TestSet.csv")
KB = os.path.join(HERE, "knowledge_base")


def normalise(text):
    """Collapse all runs of whitespace so a line break inside the corpus does not
    cause a correctly copied anchor to fail."""
    return re.sub(r"\s+", " ", text).strip().upper()


def main():
    if not os.path.exists(CSV):
        sys.exit(f"Not found: {CSV}\nRename your filled-in template to PurpleR_TestSet.csv")

    files = sorted(glob.glob(os.path.join(KB, "*.txt")))
    if not files:
        sys.exit(f"No .txt files in {KB}")

    corpus = {}
    for path in files:
        with open(path, encoding="utf-8") as handle:
            corpus[os.path.basename(path)] = normalise(handle.read())
    print(f"Corpus: {len(corpus)} documents\n")

    with open(CSV, encoding="utf-8-sig", newline="") as handle:
        rows = [r for r in csv.DictReader(handle) if (r.get("ID") or "").strip()]

    if not rows:
        sys.exit("No rows found. Fill in the template first.")

    problems = []
    warnings = []
    anchor_count = 0

    for row in rows:
        qid = row["ID"].strip()
        qtype = (row.get("Type") or "").strip().lower()
        difficulty = (row.get("Difficulty") or "").strip().lower()
        anchors = [(row.get(f"Evidence_Anchor_{i}") or "").strip() for i in (1, 2, 3)]
        anchors = [a for a in anchors if a]

        if not (row.get("Question") or "").strip():
            problems.append(f"{qid}: Question is empty")
        if not (row.get("Reference_Answer") or "").strip():
            problems.append(f"{qid}: Reference_Answer is empty")

        if qtype == "unanswerable":
            if anchors:
                problems.append(
                    f"{qid}: unanswerable questions must have no evidence anchors, found {len(anchors)}")
            if (row.get("Answer_Keys") or "").strip():
                warnings.append(f"{qid}: unanswerable question has Answer_Keys; usually left blank")
            continue

        if not anchors:
            problems.append(f"{qid}: answerable question has no evidence anchor")
            continue
        if difficulty == "difficult" and len(anchors) < 2:
            warnings.append(
                f"{qid}: marked Difficult but has only one anchor — is it really difficult?")
        if not (row.get("Answer_Keys") or "").strip():
            problems.append(f"{qid}: Answer_Keys is empty")

        for position, anchor in enumerate(anchors, start=1):
            anchor_count += 1
            needle = normalise(anchor)
            if len(needle) < 12:
                warnings.append(f"{qid} anchor {position}: very short ({len(needle)} chars), "
                                "may match text that is not really the evidence")
            found = [name for name, text in corpus.items() if needle in text]
            if found:
                print(f"  OK    {qid} anchor {position}  ->  {found[0]}")
            else:
                print(f"  FAIL  {qid} anchor {position}  ->  NOT FOUND")
                problems.append(f"{qid} anchor {position} is not in any corpus file: {anchor[:60]!r}")

    answerable = sum(1 for r in rows if (r.get("Type") or "").strip().lower() == "answerable")
    unanswerable = sum(1 for r in rows if (r.get("Type") or "").strip().lower() == "unanswerable")

    print("\n" + "=" * 68)
    print(f"Questions      : {len(rows)}  ({answerable} answerable, {unanswerable} unanswerable)")
    print(f"Anchors checked: {anchor_count}")

    if len(rows) < 10:
        problems.append(f"Only {len(rows)} questions; the project requires at least 10")
    if answerable < 1 or unanswerable < 1:
        problems.append("Both answerable and unanswerable questions must be represented")

    for warning in warnings:
        print(f"  warning: {warning}")

    if problems:
        print("\nPROBLEMS TO FIX:")
        for problem in problems:
            print(f"  - {problem}")
        sys.exit(1)

    print("\nAll checks passed. Send this output to Mark together with the CSV.")


if __name__ == "__main__":
    main()
