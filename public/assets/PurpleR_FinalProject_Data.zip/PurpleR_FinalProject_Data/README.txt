PurpleR - Final Project Data Package
ITC-C508 (Deep Learning and NLP) - Final Project: RAG Chatbot Development and Evaluation

Group Purple R: Mark Emmanuel P. Sagarino, Ram Kelly Jerzen Leliza, Sean John C. Dizon
College of Computer Studies, Jose Rizal University


SUPERSEDES
----------
This archive replaces PurpleR_RAG_Experiment_Data.zip, which was built for the earlier
WW-F1/F2 lab exercise. That archive carried ten questions and described a two-device
CPU-versus-GPU procedure. Neither applies to the final project. If you still have the old
archive, delete it so it cannot be uploaded by mistake.


WHAT IS IN THIS ARCHIVE
-----------------------

knowledge_base/                  The source documents indexed by the chatbot. 73,652
                                 characters across five files.

  01_RA7394_Consumer_Act.txt     Republic Act No. 7394, selected provisions on warranties,
                                 defects and remedies.
  02_RA8792_ECommerce_Act.txt    Republic Act No. 8792, provisions giving electronic
                                 records legal effect and applying Consumer Act penalties
                                 online.
  03_RA10642_Lemon_Law.txt       Republic Act No. 10642, the Philippine Lemon Law in full
                                 apart from purely administrative sections.
  04_RA11967_Internet_...txt     Republic Act No. 11967, the Internet Transactions Act
                                 of 2023.
  05_DTI_Consumer_Guidance.txt   Department of Trade and Industry consumer rights and the
                                 complaint-filing procedure.

PurpleR_TestSet.csv              The evaluation test set: twelve questions, nine
                                 answerable and three unanswerable, with reference
                                 answers, verbatim evidence anchors and answer keys.
                                 Authored by R. K. J. Leliza. The notebook reads this file
                                 directly, so the questions used in the experiment and the
                                 questions documented here cannot diverge.

TestSet_Rationale.md             Why each of the twelve questions is in the set, and the
                                 two anchor rules applied beyond plain verbatim matching.


THE TEST SET
------------

Twelve questions. The project requires at least ten, with both answerable and
unanswerable questions represented.

  Answerable    9   E1-E3 easy, A1-A3 average, D1-D3 difficult
  Unanswerable  3   U1-U3; the corpus does not contain the answer and the chatbot
                    must decline rather than assemble a plausible figure

An evidence anchor is a short string copied verbatim out of a corpus file. A retrieved
chunk counts as relevant when its text contains at least one anchor for that question.
Anchors are used instead of chunk identifiers because chunk identifiers change whenever
the chunk size changes, and the chunking experiment varies the chunk size by design.

Two further rules were applied by hand to all 21 anchors:

  1. No anchor crosses a line break in its source file, so a chunk boundary cannot split
     an anchor in half and cause the chunk that really holds the evidence to be scored
     irrelevant.
  2. Every anchor occurs exactly once in the whole corpus, so an anchor cannot mark a
     passage the answer does not rely on.

Both properties were re-verified independently after the set was handed over.

Unanswerable questions carry no anchors. An unanswerable question with an anchor would
mean the corpus answers it after all.


HOW TO USE IT
-------------

Upload this archive when the notebook PurpleR_FinalProject_RAG.ipynb asks for it. The
notebook extracts knowledge_base/ and reads PurpleR_TestSet.csv.

The final project is a single GPU run. There is no CPU run and no device comparison;
that belonged to the earlier WW-F1/F2 exercise.

VERIFICATION ARTIFACTS
----------------------

verify_anchors.py                Checks that every evidence anchor appears verbatim in
                                 the corpus, that unanswerable rows carry none, and that
                                 the set meets the ten-question minimum.
verify_anchors_output.txt        Its output on this archive. 21 anchors, all found.

purpler_testset_check.py         Pre-flight check run before the notebook: corpus size,
                                 row counts, anchor uniqueness, single-line anchors,
                                 undefined-not-zero scores for unanswerable rows, every
                                 gold answer scoring 1.00, a content-free answer scoring
                                 0.00, and a lint pass over the answer-key variants.
                                 Drafted with AI assistance (Claude) during S. J. C.
                                 Dizon's review of the test set; reviewed and run by him.
preflight_output.txt             Its output on this archive. 47 checks, zero failures.

Both scripts are reproducible: run them against this folder and they should print the
same thing.
