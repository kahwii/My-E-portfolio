#!/usr/bin/env python3
"""
PurpleR_TestSet pre-flight check
Group Purple R - ITC-C508 Final Project

Run this against PurpleR_TestSet.csv + knowledge_base/ BEFORE the notebook run.
Everything here is mechanical: no judgement calls, no network, no model.

    python purpler_testset_check.py <path-to-data-folder>

The folder must contain PurpleR_TestSet.csv and knowledge_base/.
Exit code 0 = all checks passed, 1 = at least one FAIL.

WHAT IT CHECKS
  1  Corpus size and row counts match the README.
  2  Every evidence anchor occurs EXACTLY ONCE in the whole corpus.
  3  Every evidence anchor sits inside a SINGLE LINE of its source file.
  4  Unanswerable rows carry no anchors and no answer keys.
  5  Every gold Reference_Answer scores 1.00 against its own Answer_Keys.
     (A gold answer that cannot score 1.00 means the chatbot cannot either.)
  6  A content-free "spam" answer that only name-drops the statutes scores 0.00
     on every easy and average question.
  7  LINT: answer-key variants that are likely to misfire -
       - a digit-only variant needs word-boundary matching, or "4" matches
         inside "7394";
       - an inflected variant ("excluded") misses other forms ("excludes");
         the stem ("exclud") catches both.
"""

import csv
import os
import re
import sys

KB_FILES = [
    "01_RA7394_Consumer_Act.txt",
    "02_RA8792_ECommerce_Act.txt",
    "03_RA10642_Lemon_Law.txt",
    "04_RA11967_Internet_Transactions_Act.txt",
    "05_DTI_Consumer_Guidance.txt",
]
EXPECTED_CHARS = 73652
EXPECTED_ANCHORS = 21
ANCHOR_COLS = ("Evidence_Anchor_1", "Evidence_Anchor_2", "Evidence_Anchor_3")

SPAM = ("I am not sure, but this is governed by Republic Act No. 7394, "
        "Republic Act No. 8792 and Republic Act No. 11967.")

failures = []


def check(ok, label, detail=""):
    print(f"  {'ok  ' if ok else 'FAIL'} {label}" + (f"  -- {detail}" if detail else ""))
    if not ok:
        failures.append(label)
    return ok


# ---------------------------------------------------------------- scoring ---
def answer_quality(answer, answer_keys):
    """The agreed rule: ';' separates required facts, '|' separates accepted
    variants of one fact. A digit-only variant must match as a whole number,
    otherwise '4' is found inside '7394'. Returns None when there are no keys,
    because answer quality is undefined for an unanswerable question - not zero.
    """
    keys = [k.strip() for k in answer_keys.split(";") if k.strip()]
    if not keys:
        return None
    low = answer.lower()

    def hit(variant):
        v = variant.strip().lower()
        if v.isdigit():
            return re.search(rf"\b{re.escape(v)}\b", low) is not None
        return v in low

    return sum(1 for k in keys if any(hit(v) for v in k.split("|"))) / len(keys)


def main(folder):
    csv_path = os.path.join(folder, "PurpleR_TestSet.csv")
    kb_dir = os.path.join(folder, "knowledge_base")
    if not os.path.isfile(csv_path) or not os.path.isdir(kb_dir):
        sys.exit(f"Need PurpleR_TestSet.csv and knowledge_base/ inside {folder}")

    # Two encoding/NA traps, both silent:
    #   - The file carries a UTF-8 BOM. Read it as plain "utf-8" and the first
    #     column is named "﻿ID", so row["ID"] raises KeyError. Use
    #     "utf-8-sig". (pandas' C parser strips the BOM on its own, so pandas
    #     is unaffected - but anything using the csv module is not.)
    #   - csv.DictReader gives "" for an empty cell. pandas.read_csv gives NaN
    #     (a float) unless you pass keep_default_na=False, and NaN.split()
    #     raises AttributeError on the unanswerable rows.
    with open(csv_path, encoding="utf-8-sig") as fh:
        rows = list(csv.DictReader(fh))

    docs, lines = {}, {}
    for name in KB_FILES:
        text = open(os.path.join(kb_dir, name), encoding="utf-8").read()
        docs[name] = text
        lines[name] = text.split("\n")

    print("\n[1] corpus and row counts")
    total = sum(len(t) for t in docs.values())
    check(total == EXPECTED_CHARS, "corpus is 73,652 characters", f"got {total:,}")
    check(len(rows) == 12, "12 rows", f"got {len(rows)}")
    answerable = [r for r in rows if r["Type"] == "Answerable"]
    unanswerable = [r for r in rows if r["Type"] == "Unanswerable"]
    check(len(answerable) == 9, "9 answerable", f"got {len(answerable)}")
    check(len(unanswerable) == 3, "3 unanswerable", f"got {len(unanswerable)}")

    print("\n[2,3] evidence anchors - unique in corpus, and inside one line")
    n_anchors = 0
    for r in rows:
        for col in ANCHOR_COLS:
            a = (r[col] or "").strip()
            if not a:
                continue
            n_anchors += 1
            occurrences = sum(d.count(a) for d in docs.values())
            one_line = any(a in ln for f in KB_FILES for ln in lines[f])
            check(occurrences == 1 and one_line,
                  f"{r['ID']} anchor {col[-1]}",
                  f"occurrences={occurrences} single_line={one_line} len={len(a)}")
    check(n_anchors == EXPECTED_ANCHORS, "21 anchors total", f"got {n_anchors}")

    print("\n[4] unanswerable rows carry nothing to score against")
    for r in unanswerable:
        anchors = [r[c] for c in ANCHOR_COLS if (r[c] or "").strip()]
        check(not anchors and not (r["Answer_Keys"] or "").strip(),
              f"{r['ID']} has no anchors and no keys",
              f"anchors={len(anchors)} keys={r['Answer_Keys']!r}")
        check(answer_quality("Not in the corpus.", r["Answer_Keys"]) is None,
              f"{r['ID']} scores None, not 0.0")

    print("\n[5] every gold answer scores 1.00 against its own keys")
    for r in answerable:
        q = answer_quality(r["Reference_Answer"], r["Answer_Keys"])
        detail = ""
        if q != 1.0:
            missed = [k.strip() for k in r["Answer_Keys"].split(";")
                      if k.strip() and not any(
                          v.strip().lower() in r["Reference_Answer"].lower()
                          for v in k.split("|"))]
            detail = f"score={q:.2f} unsatisfied key(s)={missed}"
        check(q == 1.0, f"{r['ID']} gold = 1.00", detail)

    print("\n[6] a content-free answer that only cites statute numbers")
    print(f"      {SPAM!r}")
    for r in answerable:
        q = answer_quality(SPAM, r["Answer_Keys"])
        if r["Difficulty"] in ("Easy", "Average"):
            check(q == 0.0, f"{r['ID']} spam = 0.00", f"got {q:.2f}")
        else:
            # Difficult rows legitimately award partial credit for naming the
            # right statute, so a non-zero score here is expected, not a bug.
            print(f"  note {r['ID']} spam = {q:.2f} (expected: statute names are "
                  f"part of the correct answer)")

    print("\n[7] lint - answer-key variants likely to misfire")
    clean = True
    for r in rows:
        for key in (r["Answer_Keys"] or "").split(";"):
            for v in key.split("|"):
                v = v.strip()
                if not v:
                    continue
                if v.isdigit():
                    print(f"  note {r['ID']}: digit-only variant {v!r} - needs "
                          f"word-boundary matching (answer_quality does this)")
                    clean = False
                elif re.fullmatch(r"[a-z]+(ed|ing)", v.lower()):
                    stem = re.sub(r"(ed|ing)$", "", v.lower())
                    print(f"  WARN {r['ID']}: inflected variant {v!r} will miss "
                          f"other forms - consider the stem {stem!r}")
                    clean = False
    if clean:
        print("  ok   no risky variants")

    print("\n" + "=" * 60)
    if failures:
        print(f"{len(failures)} FAILURE(S):")
        for f in failures:
            print(f"  - {f}")
        return 1
    print("All checks passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "."))
