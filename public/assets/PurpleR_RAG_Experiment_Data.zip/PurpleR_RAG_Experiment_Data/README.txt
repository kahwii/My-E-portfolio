PurpleR - RAG Experiment Data
ITC-C508 Lab Exercise WW1 and WW2 (Optimization and GPU Testing)

Group Purple R: Mark Emmanuel P. Sagarino, Ram Kelly Jerzen Leliza, Sean John C. Dizon
College of Computer Studies, Jose Rizal University


WHAT IS IN THIS ARCHIVE
-----------------------

knowledge_base/                  The source documents indexed by the chatbot.
  01_RA7394_Consumer_Act.txt     Republic Act No. 7394, selected provisions on warranties,
                                 defects and remedies.
  02_RA8792_ECommerce_Act.txt    Republic Act No. 8792, provisions giving electronic records
                                 legal effect and applying Consumer Act penalties online.
  03_RA10642_Lemon_Law.txt       Republic Act No. 10642, the Philippine Lemon Law in full
                                 apart from purely administrative sections.
  04_RA11967_Internet_...txt     Republic Act No. 11967, the Internet Transactions Act of 2023.
  05_DTI_Consumer_Guidance.txt   Department of Trade and Industry consumer rights and the
                                 complaint-filing procedure.

test_questions.json              The test-question set in machine-readable form. The notebook
                                 loads this file directly, so the questions used in the
                                 experiment and the questions documented here cannot diverge.

test_questions.csv               The same set as a spreadsheet, for reading.

README.txt                       This file.


THE DATASET
-----------

5 documents, 73,652 characters of statutory and agency text. All of it is
public. Republic Acts are works of the Government of the Philippines and are not subject to
copyright; the Department of Trade and Industry pages carry the notice that all content is in the
public domain unless otherwise stated. Statutory text is reproduced verbatim: provisions outside
the scope of the chatbot were omitted rather than summarised, so no passage appears in paraphrase.


THE TEST-QUESTION SET
---------------------

9 scored questions, three at each difficulty level, plus one guardrail question.

  Easy       E1 E2 E3    one explicit fact in a single passage
  Average    A1 A2 A3    interpretation, or two closely related facts
  Difficult  D1 D2 D3    several passages, or an exclusion that must be recognised
  Guardrail  G1          deliberately unanswerable from this corpus

Difficulty comes from the amount of evidence an answer needs, not from vague wording. Every
scored question is fully answerable from the documents in knowledge_base/.


HOW RETRIEVAL AND ANSWERS ARE SCORED
------------------------------------

Chunk identifiers change whenever the chunk size changes, so ground truth cannot be a list of
chunk identifiers. Each question therefore carries one or more EVIDENCE ANCHORS: short verbatim
strings taken from the source text, each being the minimum span that carries the fact.
19 anchors are defined across the 9 scored questions.

  Retrieval relevance   A retrieved chunk is relevant when its text contains at least one anchor
                        for that question. Recall@k is the proportion of a question's anchors
                        covered by the top-k chunks.

  Answer quality        Each question carries ANSWER KEYS - the facts a correct answer must
                        state. A key may list acceptable variants separated by a vertical bar,
                        so "four|4" is satisfied by either spelling. Answer quality is the
                        fraction of keys the generated answer satisfies.

Both tests are mechanical and identical at every configuration and on both devices, which is what
makes the comparison fair.

The guardrail question G1 has no anchors and no keys. It is excluded from the metrics, which are
undefined when no relevant evidence exists, and is reported separately: the correct behaviour is a
refusal.


REPRODUCING THE EXPERIMENT
--------------------------

1. Open PurpleR_RAG_Experiment_Notebook.ipynb in Google Colab.
2. Upload this archive, or upload knowledge_base/ and test_questions.json separately.
3. Runtime -> Change runtime type -> CPU. Run all. The notebook writes results_CPU.csv.
4. Runtime -> Change runtime type -> T4 GPU. Restart and run all. It writes results_GPU.csv.
5. The merge section combines whichever device files are present and computes the speedups.

The notebook detects the active device itself and tags its results accordingly, so the two runs
cannot be confused with one another.
